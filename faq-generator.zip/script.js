function done(){
  phoneName = document.getElementById("name").value;
  console.log(phoneName);

  var intro = phoneName + "is an upcoming smartphone. In this article, We will be talking about the specifications and FAQs of " + phoneName +". We will look at the specifications and answer the frequently asked questions about " + phoneName + ".<br>";

  var sim, sim5g, sim4g, nfc, fm, water, wireless, battery, led, finger, faceid, screc, offline, gaming, pubg, fortnite, cod, android12, freefire;
  var main = "";
  console.log(document.getElementById("dual").options[document.getElementById("dual").selectedIndex].text);
  if(document.getElementById("dual").options[document.getElementById("dual").selectedIndex].text == "Yes")
  {
    sim = "Yes. " + phoneName + " comes with dual sim setup. (Nano-SIM, dual stand-by)";  }
  else{
    sim = "No. " + phoneName + " doesn't comes with dual sim setup."
  }
  /* 5G or not */
  if(document.getElementById("5g").options[document.getElementById("5g").selectedIndex].text == "Yes")
  {
    sim5g = "Yes. " + phoneName + " comes with a 5G sim support. You can enjoy 5G on this smartphone.";  }
  else{
    sim5g = "No. " + phoneName + " doesn't comes with 5G sim setup. If you want a 5G smartphone buy something else."
  }
  if(document.getElementById("4g").options[document.getElementById("4g").selectedIndex].text == "Yes")
  {
    sim4g = "Yes. " + phoneName + " comes with 4G sim support. (Nano-SIM, dual stand-by)";  }
  else{
    sim4g = "No. " + phoneName + " doesn't comes with 4G sim setup. Pretty old school phone"
  }
  if(document.getElementById("nfc").options[document.getElementById("nfc").selectedIndex].text == "Yes")
  {
    nfc = "Yes. " + phoneName + " will be launching with NFC support.";  }
  else{
    nfc = "No. " + phoneName + " doesn't have NFC support"
  }
  if(document.getElementById("radio").options[document.getElementById("radio").selectedIndex].text == "Yes")
  {
    fm = "Yes. " + phoneName + " comes with FM radio. You can open the FM radio app and Enjoy music.";  }
  else{
    fm = "No. " + phoneName + " doesn't comes with FM Radio. Get ready with Modern Radios with Spotify and YouTube Music"
  }
  if(document.getElementById("water").options[document.getElementById("water").selectedIndex].text == "Yes")
  {
    water = "Yes. " + phoneName + " is a waterproof phone. It received the IP68 rating. Along with the ratings many YouTube videos about water test tell us that this phone is waterproof.";  }
  else{
    water = "No. " + phoneName + " doesn't have any WaterProofing. You can't take your phone in shower or swimming. It can damage your smartphone as it doesn't come with IP68 rating."
  }
  if(document.getElementById("wireless").options[document.getElementById("wireless").selectedIndex].text == "Yes")
  {
    wireless = "Yes. " + phoneName + " comes with Wireless charging support. You can charge with Wireless chargers.";  }
  else{
    wireless = "No. " + phoneName + " doesn't comes with Wireless charging support. You can't charge with Wireless chargers."
  }
  if(document.getElementById("removable").options[document.getElementById("removable").selectedIndex].text == "Yes")
  {
    battery = "Yes. " + phoneName + " comes with ability to remove battery. Huh! Pretty old school.";  }
  else{
    battery = "No. " + phoneName + " doesn't comes with the ability to remove battery. It's pretty common in new smartphone as it allows manufacturers to put battery in any shape and increase battery capacity."
  }
  if(document.getElementById("led").options[document.getElementById("led").selectedIndex].text == "Yes")
  {
    led = "Yes. " + phoneName + " comes with LED notifications feature. You can enable it from the Settings section of phone.";  }
  else{
    led = "No. " + phoneName + " doesn't comes with LED notifications feature. Well you can install an app for that from Play Store."
  }
  if(document.getElementById("scanner").options[document.getElementById("scanner").selectedIndex].text == "Yes")
  {
    finger = "Yes. " + phoneName + " support Fingerprint scanner. You can use it to unlock your smartphone and also take photos by tapping on the fingerprint scanner";  }
  else{
    finger = "No. " + phoneName + " doesn't have a fingerprint scanner. Be ready with a hard to guess Pin or Pattern to unlock your smartphone."
  }
  if(document.getElementById("faceid").options[document.getElementById("faceid").selectedIndex].text == "Yes")
  {
    faceid = "Yes. " + phoneName + " comes with FACE ID support. You can use FACE ID to instantly unlock your smartphone.";  }
  else{
    faceid = "No. " + phoneName + " doesn't comes with FACE ID support. You can use Fingerprint scanner or pattern lock to secure your phone."
  }
  if(document.getElementById("scr").options[document.getElementById("scr").selectedIndex].text == "Yes")
  {
    screc = "Yes. " + phoneName + " comes with Screen Recording by default. You need to open Action center and then tap on screen recording to use Screen Recording feature.";  }
  else{
    screc = "No. " + phoneName + " doesn't comes with Screen recording feature by default. You can use Omlete Arcade or AZRecorder to record your smartphone screen. It works quite good."
  }
  if(document.getElementById("offline").options[document.getElementById("offline").selectedIndex].text == "Yes")
  {
    offline = "Yes. " + phoneName + " is also available in Offline smartphone market. You can purchase it from your nearest store or market.";  }
  else{
    offline = "No. " + phoneName + " is not available offline. You can purchase it from official website or Best Buy and Amazon."
  }
  if(document.getElementById("gaming").options[document.getElementById("gaming").selectedIndex].text == "Yes")
  {
    gaming = "Yes. " + phoneName + " is a gaming smartphone and you can enjoy high-end games on this smartphone.";  }
  else{
    gaming = "No. " + phoneName + " is not a gaming smartphone. However, you can still run low-end and middle range games on this smartphone."
  }
  if(document.getElementById("pubg").options[document.getElementById("pubg").selectedIndex].text == "Yes")
  {
    pubg = "Yes. " + phoneName + " can easily run the PUBG game and you can enjoy the Battleground game without any lag or throttling.";  }
  else{
    pubg = "No. " + phoneName + " can't run resource hungry game like PUBG. You can still play the low-end games."
  }
  if(document.getElementById("fortnite").options[document.getElementById("fortnite").selectedIndex].text == "Yes")
  {
    fortnite = "Yes. " + phoneName + " can easily run the Fortnite game and you can enjoy the Battleground game without any lag or throttling.";  }
  else{
    fortnite = "No. " + phoneName + " can't run resource hungry game like Fortnite. You can still play the low-end games."
  }
  if(document.getElementById("cod").options[document.getElementById("cod").selectedIndex].text == "Yes")
  {
    cod = "Yes. " + phoneName + " can easily run the Call of Duty mobile game and you can enjoy the Battleground and multiplayer game without any lag or throttling.";  }
  else{
    cod = "No. " + phoneName + " can't run resource hungry game like COD. You can still play the low-end and middle-range games."
  }
  if(document.getElementById("freefire").options[document.getElementById("pubg").selectedIndex].text == "Yes")
  {
    freefire = "Yes. " + phoneName + " can easily run the lightweight games like FreeFire and you can enjoy the Battleground game without any lag or throttling.";  }
  else{
    freefire = "No. " + phoneName + " can't run FreeFire game and that's a bad sign. You shoudn't buy this smartphone if your intention is to play games."
  }
  if(document.getElementById("12").options[document.getElementById("12").selectedIndex].text == "Yes")
  {
    android12 = "Yes. " + phoneName + " comes with Android 12 Out of the box.";  }
  else{
    android12 = "No. " + phoneName + " doesn't comes with Android 12. You can still install a custom ROM to get Android 12 support."
  }
  main = "<h2>Is " + phoneName +" support Dual Sim?</h2><br>" + sim + "<br>" + "<h2>Is " + phoneName +" support 5G?</h2><br>" + sim5g + "<br>" + "<h2>Is " + phoneName +" supports 4G?</h2><br>" + sim4g + "<br>" + "<h2>Is " + phoneName +" supports NFC?</h2><br>" + nfc + "<br>" + "<h2>Is " + phoneName +" supports FM Radio?</h2><br>" + fm + "<br>" + "<h2>Is " + phoneName +" a Waterproof phone?</h2><br>" + water + "<br>" + "<h2>Is " + phoneName +" supports Wireless charging?</h2><br>" + wireless + "<br>" + "<h2>Is " + phoneName +" have Removable Battery?</h2><br>" + battery + "<br>" + "<h2>Is " + phoneName +" comes with LED notifications?</h2><br>" + led + "<br>" + "<h2>Is " + phoneName +" support Fingerprint scanner?</h2><br>" + finger + "<br>" + "<h2>Is " + phoneName +" supports Face ID?</h2><br>" + faceid + "<br>" + "<h2>Is " + phoneName +" supports Screen Recording?</h2><br>" + screc + "<br>" + "<h2>Is " + phoneName +" available offline?</h2><br>" + offline + "<br>" + "<h2>Is " + phoneName +" a gaming smartphone?</h2><br>" + gaming + "<br>" + "<h2>Is " + phoneName +" good for PUBG?</h2><br>" + pubg + "<br>" + "<h2>Is " + phoneName +" good for Fortnite?</h2><br>" + fortnite + "<br>" + "<h2>Is " + phoneName +" good for Call of Duty?</h2><br>" + cod + "<br>" + "<h2>Is " + phoneName +" good for FreeFire?</h2><br>" + freefire + "<br>" + "<h2>Is " + phoneName +" supports Android 12?</h2><br>" + android12 + "<br>If you found this article about " + phoneName + " FAQs and specifications. Please share it on social media and tag @droidmaze on Twitter. Also ask your question in comment section and we will update this post with your questions and answer.<br>Follow us on <a href='https://twitter.com/droidmaze'>Twitter</a> for latest news and updates regarding Android and Google.";

  document.getElementById("final_article").innerHTML = main;

}

function copyArticle() {
                    var range = document.createRange();
                    range.selectNode(document.getElementById("final_article"));
                    window.getSelection().removeAllRanges(); // clear current selection
                    window.getSelection().addRange(range); // to select text
                    document.execCommand("copy");
                    window.getSelection().removeAllRanges();// to deselect
                }